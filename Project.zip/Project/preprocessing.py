import torch
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import random
import matplotlib.pyplot as plt

def load_data(data_dir, batch_size=32, augment=True):
    transform = transforms.Compose([
        transforms.Resize((128, 128)),  # ✅ Resize to match ANN input size
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])

    if augment:
        transform = transforms.Compose([
            transforms.Resize((128, 128)),
            transforms.RandomHorizontalFlip(),
            transforms.RandomRotation(20),
            transforms.RandomAffine(10, translate=(0.1, 0.1)),  # ✅ Helps generalization
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])  # ✅ Pretrained model normalization
        ])

    try:
        train_data = datasets.ImageFolder(root=f"{data_dir}/train", transform=transform)
        val_data = datasets.ImageFolder(root=f"{data_dir}/test", transform=transform)
    except FileNotFoundError as e:
        raise FileNotFoundError("Dataset structure is incorrect. Ensure 'train' and 'test' folders exist.") from e

    train_dataloader = DataLoader(train_data, batch_size=batch_size, shuffle=True)
    val_dataloader = DataLoader(val_data, batch_size=batch_size, shuffle=False)

    return train_dataloader, val_dataloader, train_data.classes

def visualize_data(dataloader, classes, num_samples=5):
    images, labels = next(iter(dataloader))  # Get first batch
    images = images.numpy().transpose((0, 2, 3, 1))

    # Select random indices
    indices = random.sample(range(len(images)), num_samples)

    fig, axes = plt.subplots(1, num_samples, figsize=(10, 5))
    for i, idx in enumerate(indices):
        ax = axes[i]
        ax.imshow(images[idx])
        ax.set_title(classes[labels[idx].item()])
        ax.axis("off")
    plt.show()
