import os
import uuid
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
from torchvision import models
from PIL import Image
from flask import Flask, render_template, request

from Project.classification_model import Autoencoder, ResNetTransfer

app = Flask(__name__)

# Ensure 'static/uploads' directory exists
UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Define models (Simplified ANN, CNN, AlexNet, VGG)
def get_model(model_name):
    if model_name == "ANN":
        model = nn.Sequential(nn.Flatten(), nn.Linear(128*128*3, 512), nn.ReLU(), nn.Linear(512, 2))
    elif model_name == "CNN":
        model = models.resnet18(pretrained=True)
        model.fc = nn.Linear(model.fc.in_features, 2)
    elif model_name == "AlexNet":
        model = models.alexnet(pretrained=True)
        model.classifier[6] = nn.Linear(model.classifier[6].in_features, 2)
    elif model_name == "VGG":
        model = models.vgg16(pretrained=True)
        model.classifier[6] = nn.Linear(model.classifier[6].in_features, 2)
    elif model_name == "Autoencoder":
        model = Autoencoder()
    elif model_name == "ResNetTransfer":
        model = ResNetTransfer()
    else:
        raise ValueError("Invalid model selected")
    return model

# Define optimizers
def get_optimizer(optimizer_name, model):
    if optimizer_name == "Adam":
        return optim.Adam(model.parameters(), lr=0.001)
    elif optimizer_name == "SGD":
        return optim.SGD(model.parameters(), lr=0.001, momentum=0.9)
    elif optimizer_name == "RMSprop":
        return optim.RMSprop(model.parameters(), lr=0.001)
    else:
        raise ValueError("Invalid optimizer selected")

# Image transformation
transform = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.ToTensor()
])

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        # Get model and optimizer choice
        model_name = request.form.get("model")
        optimizer_name = request.form.get("optimizer")

        # Handle file upload
        file = request.files["image"]
        if file:
            filename = f"{uuid.uuid4()}_{file.filename}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            # Load model and optimizer
            model = get_model(model_name)
            optimizer = get_optimizer(optimizer_name, model)

            # Load image and preprocess
            image = Image.open(filepath).convert("RGB")
            image = transform(image).unsqueeze(0)  # Add batch dimension

            # Flatten image if model is Autoencoder or ANN
            if model_name in ["Autoencoder", "ANN"]:
                image = image.view(image.size(0), -1)

            # Make prediction
            model.eval()
            with torch.no_grad():
                output = model(image)
                predicted_class = torch.argmax(output, dim=1).item()

            # Class labels (Modify as per your dataset)
            class_labels = ["Healthy", "Diseased"]
            if predicted_class >= len(class_labels):
                prediction = "Unknown"
            else:
                prediction = class_labels[predicted_class]

            return render_template("index.html", prediction=prediction, image_path=filepath)

    return render_template("index.html", prediction=None)

if __name__ == "__main__":
    app.run(debug=True)
