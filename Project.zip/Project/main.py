import torch
import torch.nn as nn
import torch.optim as optim
import preprocessing as pre
from classification_model import DeepANN, CNN, AlexNet, VGGNet, compute_accuracy,Autoencoder,ResNetTransfer

def train_model(model, train_loader, val_loader, criterion, optimizer, scheduler, device, num_epochs=3):
    model.to(device)
    use_amp = torch.cuda.is_available()
    scaler = torch.amp.GradScaler("cuda") if use_amp else None

    total_accuracy = 0
    for epoch in range(num_epochs):
        model.train()
        train_correct = 0
        train_total = 0

        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)  # No .float().unsqueeze(1)

            optimizer.zero_grad()
            if use_amp:
                with torch.amp.autocast("cuda"):
                    outputs = model(inputs)
                    loss = criterion(outputs, labels)  # No .view(-1)
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
            else:
                outputs = model(inputs)
                loss = criterion(outputs, labels)  # No .view(-1)
                loss.backward()
                optimizer.step()

            # Compute Training Accuracy
            predictions = torch.argmax(outputs, dim=1)  # For CrossEntropyLoss
            train_correct += (predictions == labels).sum().item()
            train_total += labels.size(0)

        scheduler.step()
        train_accuracy = (train_correct / train_total) * 100
        val_accuracy = compute_accuracy(model, val_loader, device)
        total_accuracy += val_accuracy

        print(f"Epoch [{epoch+1}/{num_epochs}] - Train Acc: {train_accuracy:.2f}% - Val Acc: {val_accuracy:.2f}%")

    final_accuracy = total_accuracy / num_epochs
    print(f"\nFinal Model Accuracy: {final_accuracy:.2f}%")

def main():
    data_dir = r"C:\\deeplearning\\Project\\data"
    batch_size = 32
    train_loader, val_loader, classes = pre.load_data(data_dir, batch_size=batch_size)

    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    # Use CrossEntropyLoss for num_classes=2
    criterion = nn.CrossEntropyLoss()

    models_dict = {
        "ANN": DeepANN(input_size=128*128*3),
        "CNN": CNN(num_classes=2),  # Corrected for CrossEntropyLoss
        "AlexNet": AlexNet(num_classes=2),
        "VGG": VGGNet(num_classes=2),
        "Autoencoder":Autoencoder(),
        "ResNetTransfer":ResNetTransfer(),

    }

    optimizers_dict = {
        'SGD': optim.SGD,
        'RMSprop': optim.RMSprop,
        'Adam': optim.Adam
    }

    model_name = input("Choose a model (ANN, CNN, AlexNet, VGG, Autoencoder,ResNetTransfer): ").strip()
    optimizer_name = input("Choose an optimizer (Adam, SGD, RMSprop): ").strip()

    model = models_dict[model_name].to(device)
    optimizer = optimizers_dict[optimizer_name](model.parameters(), lr=0.0001, weight_decay=1e-4)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.1)

    train_model(model, train_loader, val_loader, criterion, optimizer, scheduler, device, num_epochs=10)

if __name__ == '__main__':
    main()
